# راهنمای اتصال و تعویض تأمین‌کنندهٔ هوش مصنوعی (AI Providers)

این سند مراحل **گام‌به‌گام** برای اتصال به چهار تأمین‌کننده رایج را شرح می‌دهد و نحوه‌ی **جایگزینی** آنها با یک متغیر محیطی را نشان می‌دهد.

## معماری انتزاعی
- فایل: `lib/providers/index.ts`
- این متد را صدا می‌زنیم:
  ```ts
  generateStream({ system, prompt, stream: true, temperature })
  ```
- انتخاب تأمین‌کننده با `AI_PROVIDER` در `.env.local`:
  ```
  AI_PROVIDER=openai | gemini | anthropic | azure
  ```

---

## 1) OpenAI (پیش‌فرض)
**Env:**
```
OPENAI_API_KEY=sk-...
OPENAI_BASE_URL=https://api.openai.com/v1   # اختیاری
OPENAI_MODEL=gpt-4o-mini                    # اختیاری
```

**مدل‌های پیشنهادی:** `gpt-4o-mini` (کیفیت/هزینه متوازن)، یا `gpt-4o` (کیفیت بالا).

**Streaming:** پیاده‌سازی شده در `lib/providers/openai.ts` با SDK رسمی (`openai@^4`) و `chat.completions.create({stream:true})`.

**نکات ایمنی و هزینه:**
- پرامپت‌ها غیرقطعی و با هشدار حساسیت نوشته شده‌اند.
- برای کنترل هزینه، `temperature` را پایین نگه دارید و حداکثر طول خواب را محدود کنید (۱۵۰۰ نویسه).
- در صورت خطا، Retry با Backoff نمایی را می‌توانید بیفزایید.

---

## 2) Google Gemini
**مسیرهای ممکن:**
- **Generative Language API** با کلید مستقیم.
- **Vertex AI** (GCP) با احراز هویت سرویس.

**Env:**
```
GEMINI_API_KEY=...
```

**مدل‌های متنی رایج:** `gemini-1.5-flash`, `gemini-1.5-pro`

**Streaming:** با SSE یا chunked fetch. الگوی راه‌اندازی:
```ts
// نمونهٔ ساده (Pseudo)
const res = await fetch(`https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:streamGenerateContent?key=${process.env.GEMINI_API_KEY}`, {
  method: "POST",
  headers: {"Content-Type":"application/json"},
  body: JSON.stringify({
    contents: [{ role: "user", parts: [{ text: `${system}\n\n${prompt}` }]}]
  })
});
// سپس خواندن استریم و enqueue به ReadableStream مشابه OpenAI
```

**ایمنی:** از پارامترهای Safety Settings برای محدودسازی خروجی‌های آسیب‌زا استفاده کنید.

**هزینه/سقف:** نسخه‌های Flash ارزان‌تر از Pro هستند؛ برای ترافیک عمومی Flash کافی است.

---

## 3) Anthropic Claude
**Env:**
```
ANTHROPIC_API_KEY=...
```

**مدل‌ها:** `claude-3-haiku` (سریع/ارزان)، `claude-3-sonnet`, `claude-3-opus` (قوی‌تر)

**Streaming (Messages API):**
```ts
// Pseudo
const res = await fetch("https://api.anthropic.com/v1/messages", {
  method: "POST",
  headers: {
    "x-api-key": process.env.ANTHROPIC_API_KEY!,
    "anthropic-version": "2023-06-01",
    "content-type":"application/json"
  },
  body: JSON.stringify({
    model: "claude-3-haiku",
    max_tokens: 1024,
    messages: [{ role:"user", content: `${system}\n\n${prompt}` }],
    stream: true
  })
});
// خواندن رویدادهای استریم و ارسال به ReadableStream
```

**ایمنی:** از پارامترهای Safety/Blockings بهره ببرید.

---

## 4) Azure OpenAI
**Env:**
```
AZURE_OPENAI_API_KEY=...
AZURE_OPENAI_ENDPOINT=https://YOUR_RESOURCE_NAME.openai.azure.com
AZURE_OPENAI_DEPLOYMENT=YOUR_DEPLOYMENT_NAME  # مثلاً gpt-4o-mini
AZURE_OPENAI_API_VERSION=2024-06-01
```

**Streaming:**
```ts
// Pseudo
const url = `${process.env.AZURE_OPENAI_ENDPOINT}/openai/deployments/${process.env.AZURE_OPENAI_DEPLOYMENT}/chat/completions?api-version=${process.env.AZURE_OPENAI_API_VERSION}`;
const res = await fetch(url, {
  method: "POST",
  headers: {
    "api-key": process.env.AZURE_OPENAI_API_KEY!,
    "content-type": "application/json"
  },
  body: JSON.stringify({
    messages: [{ role: "system", content: system }, { role: "user", content: prompt }],
    stream: true
  })
});
// parse SSE as with OpenAI
```

**سهمیه‌ها/منطقه:** بر اساس Region متفاوت است؛ از Deployment Name درست استفاده کنید.

---

## تعویض سریع Provider
1) مقدار `AI_PROVIDER` را در `.env.local` تغییر دهید.
2) کلیدها و پارامترهای لازم همان Provider را اضافه کنید.
3) `npm run dev` را ری‌استارت کنید.

---

## امنیت
- **کلیدها فقط در سرور**: هرگز در کلاینت ارسال نشوند.
- **چرخش کلید**: در صورت نشت، فوراً revocation و جایگزینی.
- **CSP/Headers**: در `next.config.js` هدرهای امنیتی پایه افزوده شده‌اند.

## کارایی
- **Edge Runtime** برای API فعال است.
- **Caching**: دارایی‌های استاتیک از Next به‌صورت خودکار کش می‌شوند.
- **دمای پیش‌فرض**: 0.2–0.5 جهت پایداری متن و هزینه.
- **حالت قطعی برای تست**: می‌توانید دما را صفر و مدل سبک‌تر انتخاب کنید.

## نکات هزینه
- ورودی ۱۵۰۰ نویسه و پاسخ‌های چند پاراگرافی معمولاً ارزان هستند.
- حالت «هردو» دو درخواست همزمان می‌فرستد؛ در قیمت‌گذاری لحاظ کنید.