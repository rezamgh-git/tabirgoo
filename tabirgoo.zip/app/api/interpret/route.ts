import { NextRequest } from "next/server";
import { dreamSchema } from "@/lib/validation";
import { buildTraditionalPrompt } from "@/lib/prompts/traditional";
import { buildScientificPrompt } from "@/lib/prompts/scientific";
import { normalizeDream } from "@/lib/format";
import { generateStream } from "@/lib/providers";
import { getClientIP } from "@/lib/utils";
import { rateLimit } from "@/lib/rate-limit";

export const runtime = "edge";

export async function POST(req: NextRequest) {
  try {
    const ip = getClientIP(req);
    const rl = rateLimit(ip);
    if (!rl.allowed) {
      return new Response(
        JSON.stringify({
          error: "محدودیت درخواست: حداکثر ۵ درخواست در دقیقه.",
          retryAfterMs: rl.resetMs
        }),
        {
          status: 429,
          headers: {
            "content-type": "application/json; charset=utf-8",
            "x-ratelimit-remaining": String(rl.remaining)
          }
        }
      );
    }

    const body = await req.json();
    const parsed = dreamSchema.safeParse(body);
    if (!parsed.success) {
      return new Response(
        JSON.stringify({ error: parsed.error.issues[0]?.message ?? "ورودی نامعتبر" }),
        { status: 400, headers: { "content-type": "application/json; charset=utf-8" } }
      );
    }
    const { text, mode } = parsed.data;
    const dream = normalizeDream(text);

    const { system, user } =
      mode === "traditional"
        ? buildTraditionalPrompt(dream)
        : buildScientificPrompt(dream);

    const stream = await generateStream({
      system,
      prompt: user,
      temperature: mode === "traditional" ? 0.5 : 0.2,
      stream: true
    });

    return new Response(stream, {
      status: 200,
      headers: {
        "content-type": "text/plain; charset=utf-8"
      }
    });
  } catch (err: any) {
    console.error(err);
    return new Response(
      JSON.stringify({
        error:
          "در حال حاضر امکان تولید پاسخ وجود ندارد. لطفاً دوباره تلاش کنید."
      }),
      { status: 500, headers: { "content-type": "application/json; charset=utf-8" } }
    );
  }
}