"use client";
import { APP_DISCLAIMER_FA } from "@/lib/version";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useEffect, useState } from "react";

export default function Footer() {
  const [optIn, setOptIn] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("analyticsOptIn");
    setOptIn(stored === "true");
  }, []);
  useEffect(() => {
    localStorage.setItem("analyticsOptIn", optIn ? "true" : "false");
    // Load a local (no-tracking) analytics stub only if opted in
    const id = "analytics-script";
    const existing = document.getElementById(id);
    if (optIn && !existing) {
      const s = document.createElement("script");
      s.id = id;
      s.src = "/analytics.js";
      s.defer = true;
      document.body.appendChild(s);
    } else if (!optIn && existing) {
      existing.remove();
    }
  }, [optIn]);

  return (
    <footer className="border-t border-slate-200/60 dark:border-slate-800/60 mt-8">
      <div className="container mx-auto max-w-5xl px-4 py-6 flex flex-col gap-3">
        <p className="text-sm opacity-80">{APP_DISCLAIMER_FA}</p>
        <div className="flex items-center gap-2">
          <Switch id="analytics" checked={optIn} onCheckedChange={setOptIn} />
          <Label htmlFor="analytics" className="text-sm opacity-90">
            فعال‌سازی تحلیل بازدید (اختیاری)
          </Label>
        </div>
        <p className="text-xs opacity-70">
          حریم خصوصی: هیچ دادهٔ شخصی یا رؤیا روی سرور ذخیره نمی‌شود.
        </p>
      </div>
    </footer>
  );
}
