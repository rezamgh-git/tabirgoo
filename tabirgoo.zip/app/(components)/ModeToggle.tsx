"use client";

import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import IconSun from "@/components/icons/IconSun";
import IconMoon from "@/components/icons/IconMoon";

export default function ModeToggle() {
  const { theme, setTheme } = useTheme();
  const isDark = theme === "dark";
  return (
    <Button
      variant="ghost"
      size="sm"
      aria-label="تغییر حالت روشن/تاریک"
      onClick={() => setTheme(isDark ? "light" : "dark")}
    >
      {isDark ? <IconSun className="w-5 h-5" /> : <IconMoon className="w-5 h-5" />}
      <span className="sr-only">تغییر تم</span>
    </Button>
  );
}
