"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function ResultCard({
  title,
  content,
  loading
}: {
  title: string;
  content: string;
  loading: boolean;
}) {
  const [copied, setCopied] = useState(false);

  return (
    <Card className="flex flex-col">
      <div className="flex items-center justify-between px-4 pt-3">
        <h3 className="font-semibold text-brand-700 dark:text-brand-300">{title}</h3>
        <Button
          variant="ghost"
          size="sm"
          onClick={async () => {
            await navigator.clipboard.writeText(content);
            setCopied(true);
            setTimeout(() => setCopied(false), 1200);
          }}
        >
          {copied ? "کپی شد" : "کپی"}
        </Button>
      </div>
      <CardContent className="pt-2 pb-4">
        {loading ? (
          <div className="space-y-2">
            <div className="h-4 w-3/5 bg-slate-200 dark:bg-slate-800 animate-pulse rounded" />
            <div className="h-4 w-4/5 bg-slate-200 dark:bg-slate-800 animate-pulse rounded" />
            <div className="h-4 w-2/5 bg-slate-200 dark:bg-slate-800 animate-pulse rounded" />
          </div>
        ) : (
          <div className="whitespace-pre-wrap leading-8">{content || "—"}</div>
        )}
      </CardContent>
    </Card>
  );
}
