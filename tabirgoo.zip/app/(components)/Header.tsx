"use client";

import { APP_NAME_FA } from "@/lib/version";
import ModeToggle from "./ModeToggle";
import Image from "next/image";
import Link from "next/link";

export default function Header() {
  return (
    <header className="sticky top-0 z-30 backdrop-blur bg-white/75 dark:bg-slate-950/60 border-b border-slate-200/60 dark:border-slate-800/60">
      <div className="container mx-auto max-w-5xl px-4 py-3 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          {/* Wordmark SVG */}
          <Image src="/logo.svg" alt={APP_NAME_FA} width={28} height={28} />
          <span className="font-bold text-lg tracking-tight">{APP_NAME_FA}</span>
        </Link>
        <div className="flex items-center gap-3">
          <ModeToggle />
          <a
            className="text-xs opacity-80 hover:opacity-100 underline decoration-dotted"
            href="https://vercel.com"
            target="_blank"
            rel="noreferrer"
          >
            Deploy
          </a>
        </div>
      </div>
    </header>
  );
}
