"use client";

import { useEffect, useRef, useState } from "react";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import ResultCard from "./ResultCard";
import { APP_DISCLAIMER_FA } from "@/lib/version";
import type { Mode } from "@/types";

type SingleMode = Exclude<Mode, "both">;

const MAX = 1500;

export default function DreamForm() {
  const [text, setText] = useState("");
  const [mode, setMode] = useState<Mode>("traditional");
  const [trad, setTrad] = useState("");
  const [sci, setSci] = useState("");
  const [loadingTrad, setLoadingTrad] = useState(false);
  const [loadingSci, setLoadingSci] = useState(false);
  const tradCtrl = useRef<AbortController | null>(null);
  const sciCtrl = useRef<AbortController | null>(null);
  const [error, setError] = useState<string | null>(null);

  const remaining = MAX - text.length;

  async function streamToState(mode: SingleMode, setter: (s: string) => void, loadingSetter: (b: boolean) => void) {
    loadingSetter(true);
    const ctrl = new AbortController();
    if (mode === "traditional") tradCtrl.current = ctrl;
    else sciCtrl.current = ctrl;

    try {
      const res = await fetch("/api/interpret", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ text, mode }),
        signal: ctrl.signal
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.error || "خطا در تولید پاسخ");
      }
      const reader = res.body!.getReader();
      const dec = new TextDecoder();
      let acc = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        acc += dec.decode(value, { stream: true });
        setter(acc);
      }
      setter(acc);
    } catch (e: any) {
      setError(e.message || "مشکلی رخ داد.");
    } finally {
      loadingSetter(false);
    }
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setTrad("");
    setSci("");

    if (!text || text.trim().length < 20) {
      setError("لطفاً خواب را حداقل در ۲۰ نویسه شرح دهید.");
      return;
    }
    if (text.length > MAX) {
      setError("حداکثر طول مجاز ۱۵۰۰ نویسه است.");
      return;
    }

    if (mode === "both") {
      await Promise.all([
        streamToState("traditional", setTrad, setLoadingTrad),
        streamToState("scientific", setSci, setLoadingSci)
      ]);
    } else if (mode === "traditional") {
      await streamToState("traditional", setTrad, setLoadingTrad);
    } else {
      await streamToState("scientific", setSci, setLoadingSci);
    }
  }

  function resetAll() {
    tradCtrl.current?.abort();
    sciCtrl.current?.abort();
    setTrad("");
    setSci("");
    setText("");
    setError(null);
  }

  useEffect(() => {
    setError(null);
  }, [mode, text]);

  return (
    <div className="py-8">
      <div className="card p-5">
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="flex flex-col gap-2">
            <Label htmlFor="dream">شرح خواب</Label>
            <Textarea
              id="dream"
              dir="rtl"
              lang="fa"
              placeholder="اینجا خواب خود را با جزئیات کافی بنویسید…"
              value={text}
              onChange={(e) => setText(e.target.value)}
              maxLength={MAX}
              rows={7}
            />
            <div className={`text-xs ${remaining < 0 ? "text-red-600" : "opacity-70"}`}>
              {remaining >= 0
                ? `کاراکتر باقی‌مانده: ${remaining}`
                : `از حد مجاز فراتر رفتید (${Math.abs(remaining)})`}
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <Label>روش تعبیر</Label>
            <RadioGroup
              value={mode}
              onValueChange={(v) => setMode(v as Mode)}
              className="flex flex-wrap gap-4"
            >
              <div className="flex items-center space-x-2 space-x-reverse">
                <RadioGroupItem value="traditional" id="m1" />
                <Label htmlFor="m1">سنتی</Label>
              </div>
              <div className="flex items-center space-x-2 space-x-reverse">
                <RadioGroupItem value="scientific" id="m2" />
                <Label htmlFor="m2">علمی</Label>
              </div>
              <div className="flex items-center space-x-2 space-x-reverse">
                <RadioGroupItem value="both" id="m3" />
                <Label htmlFor="m3">هردو</Label>
              </div>
            </RadioGroup>
          </div>

          {error && (
            <div className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-md px-3 py-2">
              {error}
            </div>
          )}

          <div className="flex items-center gap-2">
            <Button type="submit" disabled={loadingTrad || loadingSci}>
              تفسیر خواب
            </Button>
            <Button type="button" variant="secondary" onClick={resetAll}>
              شروع دوباره
            </Button>
          </div>

          <p className="text-xs opacity-70">{APP_DISCLAIMER_FA}</p>
        </form>
      </div>

      <div className={`grid gap-4 mt-6 ${mode === "both" ? "lg:grid-cols-2" : ""}`}>
        {(mode === "traditional" || mode === "both") && (
          <ResultCard title="تعبیر سنتی" content={trad} loading={loadingTrad} />
        )}
        {(mode === "scientific" || mode === "both") && (
          <ResultCard title="تحلیل علمی/روان‌شناسی" content={sci} loading={loadingSci} />
        )}
      </div>
    </div>
  );
}