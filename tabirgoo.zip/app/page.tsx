import Header from "./(components)/Header";
import Footer from "./(components)/Footer";
import DreamForm from "./(components)/DreamForm";

export default function Page() {
  return (
    <main className="min-h-screen flex flex-col">
      <Header />
      <div className="flex-1 container mx-auto px-4 max-w-5xl">
        <DreamForm />
      </div>
      <Footer />
    </main>
  );
}