export const metadata = { title: "آفلاین — تعبیرگو" };

export default function OfflinePage() {
  return (
    <div className="container mx-auto max-w-xl px-4 py-16 text-center">
      <h1 className="text-2xl font-bold mb-3">اتصال اینترنت در دسترس نیست</h1>
      <p className="text-sm opacity-80">
        شما آفلاین هستید. لطفاً اتصال خود را بررسی کنید و دوباره تلاش کنید.
      </p>
    </div>
  );
}