import "./globals.css";
import { Vazirmatn } from "next/font/google";
import { APP_NAME_FA, APP_TAGLINE_FA } from "@/lib/version";
import { ThemeProvider } from "./(providers)/theme-provider";

const vazir = Vazirmatn({
  subsets: ["arabic", "latin"],
  display: "swap",
  variable: "--font-vazir"
});

export const metadata = {
  metadataBase: new URL("https://tabirgoo.example.com"),
  title: `${APP_NAME_FA} — ${APP_TAGLINE_FA}`,
  description:
    "وب‌اپ تعبیر خواب فارسی با دو حالت سنتی (باورهای عامه) و علمی (روان‌شناسی)، با استریم پاسخ.",
  applicationName: APP_NAME_FA,
  keywords: ["تعبیر خواب", "روانشناسی خواب", "سنتی", "علمی", "Tabirgoo"],
  openGraph: {
    title: APP_NAME_FA,
    description:
      "تعبیر خواب با دو رویکرد سنتی و علمی. متن فارسی، راست‌به‌چپ، تم آبی و مینیمال.",
    type: "website",
    locale: "fa_IR",
    siteName: APP_NAME_FA
  },
  icons: [{ rel: "icon", url: "/logo.svg" }]
};

export default function RootLayout({
  children
}: { children: React.ReactNode }) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <head>
        <link rel="manifest" href="/manifest.webmanifest" />
        <meta name="theme-color" content="#3f85f2" />
      </head>
      <body className={`${vazir.variable} font-vazir bg-white text-slate-900 dark:bg-slate-950 dark:text-slate-100`}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          {children}
        </ThemeProvider>
        {/* PWA Service Worker register */}
        <script dangerouslySetInnerHTML={{__html:`
          if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
            window.addEventListener('load', () => {
              navigator.serviceWorker.register('/sw.js').catch(()=>{});
            });
          }
        `}} />
      </body>
    </html>
  );
}