export function normalizeDream(text: string): string {
  return text.replace(/\s+/g, " ").trim();
}