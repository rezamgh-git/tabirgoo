// Simple in-memory sliding window rate limiter: 5 req/min/IP
type Hit = number; // timestamp ms
const BUCKET = new Map<string, Hit[]>();
const WINDOW_MS = 60_000;
const LIMIT = 5;

export function rateLimit(ip: string) {
  const now = Date.now();
  const hits = BUCKET.get(ip)?.filter((t) => now - t < WINDOW_MS) ?? [];
  if (hits.length >= LIMIT) {
    return {
      allowed: false,
      remaining: 0,
      resetMs: WINDOW_MS - (now - (hits[0] ?? now))
    };
  }
  hits.push(now);
  BUCKET.set(ip, hits);
  return {
    allowed: true,
    remaining: Math.max(0, LIMIT - hits.length),
    resetMs: WINDOW_MS
  };
}