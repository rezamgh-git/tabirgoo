export const APP_NAME_FA = "تعبیرگو";
export const APP_TAGLINE_FA = "تعبیر خواب با دو رویکرد: سنتی و علمی، به زبان فارسی.";
export const APP_DISCLAIMER_FA =
  "این سرویس صرفاً جهت سرگرمی و آموزش است و جایگزین مشاوره حرفه‌ای نیست.";