import { z } from "zod";

export const dreamSchema = z.object({
  text: z
    .string({ required_error: "متن خواب الزامی است." })
    .transform((s) => s?.trim())
    .refine((s) => !!s && s.length >= 20, {
      message: "لطفاً خواب را حداقل در ۲۰ نویسه شرح دهید."
    })
    .refine((s) => s.length <= 1500, {
      message: "حداکثر طول مجاز ۱۵۰۰ نویسه است."
    }),
  mode: z.enum(["traditional", "scientific"], {
    required_error: "انتخاب روش تعبیر الزامی است."
  })
});
export type DreamInput = z.infer<typeof dreamSchema>;