import { ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getClientIP(req: Request): string {
  const xf = req.headers.get("x-forwarded-for");
  const real = req.headers.get("x-real-ip");
  const ip = (xf?.split(",")[0]?.trim() || real || "127.0.0.1");
  return ip;
}