import type { ProviderGenerateArgs } from "@/types";

/**
 * Google Gemini (placeholder streaming)
 * See docs/ai-integration.md for exact steps, keys, and model IDs.
 */
export async function streamWithGemini({
  system,
  prompt,
  temperature = 0.3
}: ProviderGenerateArgs): Promise<ReadableStream<Uint8Array>> {
  // Minimal stub that throws if selected without setup
  if (!process.env.GEMINI_API_KEY) {
    throw new Error("GEMINI_API_KEY is not set. See docs/ai-integration.md");
  }
  // Implement per docs (Vertex or Generative Language API) — streaming SSE or chunked fetch
  // Here we concatenate system + prompt and send once as non-streaming example fallback.
  const full = `${system}\n\n${prompt}`;
  const encoder = new TextEncoder();
  return new ReadableStream<Uint8Array>({
    start(controller) {
      controller.enqueue(encoder.encode("پیکربندی Gemini کامل نشده است.\n"));
      controller.enqueue(encoder.encode("به docs/ai-integration.md مراجعه کنید.\n"));
      controller.enqueue(encoder.encode("\nپیش‌نمایش درخواست:\n"));
      controller.enqueue(encoder.encode(full.slice(0, 200)));
      controller.close();
    }
  });
}
