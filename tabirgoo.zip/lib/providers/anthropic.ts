import type { ProviderGenerateArgs } from "@/types";

/**
 * Anthropic Claude (placeholder)
 * Implement streaming via messages API as documented.
 */
export async function streamWithAnthropic({
  system,
  prompt
}: ProviderGenerateArgs): Promise<ReadableStream<Uint8Array>> {
  if (!process.env.ANTHROPIC_API_KEY) {
    throw new Error("ANTHROPIC_API_KEY is not set. See docs/ai-integration.md");
  }
  const encoder = new TextEncoder();
  return new ReadableStream<Uint8Array>({
    start(controller) {
      controller.enqueue(encoder.encode("پیکربندی Claude کامل نشده است. "));
      controller.enqueue(encoder.encode("به docs/ai-integration.md مراجعه کنید."));
      controller.close();
    }
  });
}
