import type { ProviderGenerateArgs } from "@/types";
import { streamWithOpenAI } from "./openai";
import { streamWithGemini } from "./gemini";
import { streamWithAnthropic } from "./anthropic";
import { streamWithAzureOpenAI } from "./azure";

export type ProviderName = "openai" | "gemini" | "anthropic" | "azure";

export interface Provider {
  generate(args: ProviderGenerateArgs): Promise<ReadableStream<Uint8Array>>;
}

export function getProviderName(): ProviderName {
  const p = (process.env.AI_PROVIDER || "openai").toLowerCase() as ProviderName;
  return (["openai", "gemini", "anthropic", "azure"].includes(p) ? p : "openai");
}

export async function generateStream(args: ProviderGenerateArgs) {
  const provider = getProviderName();
  switch (provider) {
    case "openai":
      return streamWithOpenAI(args);
    case "gemini":
      return streamWithGemini(args);
    case "anthropic":
      return streamWithAnthropic(args);
    case "azure":
      return streamWithAzureOpenAI(args);
    default:
      return streamWithOpenAI(args);
  }
}
