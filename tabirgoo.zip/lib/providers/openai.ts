import OpenAI from "openai";
import type { ProviderGenerateArgs } from "@/types";

/**
 * OpenAI (default) streaming via Chat Completions
 * Works on Edge runtime through fetch-based SDK.
 */
export async function streamWithOpenAI({
  system,
  prompt,
  temperature = 0.3
}: ProviderGenerateArgs): Promise<ReadableStream<Uint8Array>> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error("Missing OPENAI_API_KEY");
  }
  const baseURL = process.env.OPENAI_BASE_URL || "https://api.openai.com/v1";
  const model = process.env.OPENAI_MODEL || "gpt-4o-mini";

  const client = new OpenAI({ apiKey, baseURL });

  // Create the async iterator stream
  const stream = await client.chat.completions.create({
    model,
    temperature,
    stream: true,
    messages: [
      { role: "system", content: system },
      { role: "user", content: prompt }
    ]
  });

  const encoder = new TextEncoder();
  return new ReadableStream<Uint8Array>({
    async start(controller) {
      try {
        for await (const chunk of stream) {
          const delta = chunk.choices?.[0]?.delta?.content;
          if (delta) controller.enqueue(encoder.encode(delta));
        }
      } catch (err: any) {
        controller.error(err);
      } finally {
        controller.close();
      }
    }
  });
}
