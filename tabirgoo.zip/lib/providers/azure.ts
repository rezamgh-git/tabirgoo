import type { ProviderGenerateArgs } from "@/types";

/**
 * Azure OpenAI (placeholder)
 * Configure endpoint, deployment, and version per docs.
 */
export async function streamWithAzureOpenAI({
  system,
  prompt
}: ProviderGenerateArgs): Promise<ReadableStream<Uint8Array>> {
  if (!process.env.AZURE_OPENAI_API_KEY) {
    throw new Error("AZURE_OPENAI_API_KEY is not set. See docs/ai-integration.md");
  }
  const encoder = new TextEncoder();
  return new ReadableStream<Uint8Array>({
    start(controller) {
      controller.enqueue(encoder.encode("پیکربندی Azure OpenAI کامل نشده است. "));
      controller.enqueue(encoder.encode("به docs/ai-integration.md مراجعه کنید."));
      controller.close();
    }
  });
}
