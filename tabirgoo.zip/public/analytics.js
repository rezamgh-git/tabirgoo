// Local opt-in analytics stub (no external tracking)
(function () {
  console.log("[Analytics] Opt-in enabled");
  let count = 0;
  function track(event, data) {
    count++;
    console.log(`[Analytics] #${count} ${event}`, data || {});
  }
  track("pageview", { path: location.pathname });
  window.addEventListener("click", (e) => {
    const t = e.target;
    if (t && t.closest) {
      const btn = t.closest("button");
      if (btn) track("button_click", { text: btn.textContent?.trim() });
    }
  });
})();