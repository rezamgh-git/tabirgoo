import { describe, it, expect } from "vitest";
import { getProviderName } from "@/lib/providers";

describe("Provider switch", () => {
  it("defaults to openai", () => {
    const name = getProviderName();
    expect(["openai", "gemini", "anthropic", "azure"]).toContain(name);
  });
});