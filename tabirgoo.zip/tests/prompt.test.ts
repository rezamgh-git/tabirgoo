import { describe, it, expect } from "vitest";
import { buildTraditionalPrompt } from "@/lib/prompts/traditional";
import { buildScientificPrompt } from "@/lib/prompts/scientific";

describe("Prompt builders", () => {
  it("traditional includes dream and structure", () => {
    const p = buildTraditionalPrompt("خواب نمونه");
    expect(p.system).toContain("سنتی");
    expect(p.user).toContain("خواب کاربر");
    expect(p.user).toContain("خواب نمونه");
  });
  it("scientific includes dream and structure", () => {
    const p = buildScientificPrompt("نمونه");
    expect(p.system).toContain("روان‌شناسی");
    expect(p.user).toContain("نمونه");
  });
});
